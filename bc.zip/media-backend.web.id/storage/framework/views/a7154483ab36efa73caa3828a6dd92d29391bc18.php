<a href="/">
    <img src="/logo.svg" alt="Logo" style="height: 80px;">
</a><?php /**PATH /var/www/media-backend.web.id/resources/views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>